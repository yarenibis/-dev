/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author yaren
 */
public class Tiyatro {
    private int tiyatro_id;
    private String oyun_adi;
    private int perde_sayisi;

    public Tiyatro() {
    }

    public Tiyatro(int tiyatro_id, String oyun_adi, int perde_sayisi) {
        this.tiyatro_id = tiyatro_id;
        this.oyun_adi = oyun_adi;
        this.perde_sayisi = perde_sayisi;
    }

    public int getTiyatro_id() {
        return tiyatro_id;
    }

    public void setTiyatro_id(int tiyatro_id) {
        this.tiyatro_id = tiyatro_id;
    }

    public String getOyun_adi() {
        return oyun_adi;
    }

    public void setOyun_adi(String oyun_adi) {
        this.oyun_adi = oyun_adi;
    }

    public int getPerde_sayisi() {
        return perde_sayisi;
    }

    public void setPerde_sayisi(int perde_sayisi) {
        this.perde_sayisi = perde_sayisi;
    }
    
    
}
