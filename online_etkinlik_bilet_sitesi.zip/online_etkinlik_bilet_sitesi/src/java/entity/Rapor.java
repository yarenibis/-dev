/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

/**
 *
 * @author yaren
 */
public class Rapor {
    private int rapor_id;
    private String içerik;
    private Date tarih;
    private Yetki yetki_id;

    public Rapor() {
    }

    public Rapor(int rapor_id, String içerik, Date tarih) {
        this.rapor_id = rapor_id;
        this.içerik = içerik;
        this.tarih = tarih;
    }

    public int getRapor_id() {
        return rapor_id;
    }

    public void setRapor_id(int rapor_id) {
        this.rapor_id = rapor_id;
    }

    public String getIçerik() {
        return içerik;
    }

    public void setIçerik(String içerik) {
        this.içerik = içerik;
    }

    public Date getTarih() {
        return tarih;
    }

    public void setTarih(Date tarih) {
        this.tarih = tarih;
    }
    
    
}
