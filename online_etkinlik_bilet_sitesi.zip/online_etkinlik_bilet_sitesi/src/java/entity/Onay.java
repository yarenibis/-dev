/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

/**
 *
 * @author yaren
 */
public class Onay {
    private int onay_id;
    private Etkinlik etkinlik_id;
    private Date tarih;

    public Onay() {
    }

    public Onay(int onay_id, Etkinlik etkinlik_id, Date tarih) {
        this.onay_id = onay_id;
        this.etkinlik_id = etkinlik_id;
        this.tarih = tarih;
    }

    public int getOnay_id() {
        return onay_id;
    }

    public void setOnay_id(int onay_id) {
        this.onay_id = onay_id;
    }

    public Etkinlik getEtkinlik_id() {
        return etkinlik_id;
    }

    public void setEtkinlik_id(Etkinlik etkinlik_id) {
        this.etkinlik_id = etkinlik_id;
    }

    public Date getTarih() {
        return tarih;
    }

    public void setTarih(Date tarih) {
        this.tarih = tarih;
    }
    
    
}
