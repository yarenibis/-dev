/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

/**
 *
 * @author yaren
 */
public class Satış {
    private int satış_id;
    private Bilet bilet_id;
    private Date tarih;

    public Satış() {
    }

    public Satış(int satış_id, Bilet bilet_id, Date tarih) {
        this.satış_id = satış_id;
        this.bilet_id = bilet_id;
        this.tarih = tarih;
    }

    public int getSatış_id() {
        return satış_id;
    }

    public void setSatış_id(int satış_id) {
        this.satış_id = satış_id;
    }

    public Bilet getBilet_id() {
        return bilet_id;
    }

    public void setBilet_id(Bilet bilet_id) {
        this.bilet_id = bilet_id;
    }

    public Date getTarih() {
        return tarih;
    }

    public void setTarih(Date tarih) {
        this.tarih = tarih;
    }
    
    
    
}
