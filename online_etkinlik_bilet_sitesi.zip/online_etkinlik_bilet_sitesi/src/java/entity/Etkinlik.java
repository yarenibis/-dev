/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

/**
 *
 * @author yaren
 */
public class Etkinlik {
    private int etkinlik_id;
    private String etkinlik_adi;
    private String aciklama;
    private int mekan_id;
    private String yorumlar;
    private Date tarih_saat;
    
    public Etkinlik(){
        
    }

    public Etkinlik(int etkinlik_id, String etkinlik_adi, String aciklama, int mekan_id, String yorumlar, Date tarih_saat) {
        this.etkinlik_id = etkinlik_id;
        this.etkinlik_adi = etkinlik_adi;
        this.aciklama = aciklama;
        this.mekan_id = mekan_id;
        this.yorumlar = yorumlar;
        this.tarih_saat = tarih_saat;
    }

    public int getEtkinlik_id() {
        return etkinlik_id;
    }

    public void setEtkinlik_id(int etkinlik_id) {
        this.etkinlik_id = etkinlik_id;
    }

    public String getEtkinlik_adi() {
        return etkinlik_adi;
    }

    public void setEtkinlik_adi(String etkinlik_adi) {
        this.etkinlik_adi = etkinlik_adi;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public int getMekan_id() {
        return mekan_id;
    }

    public void setMekan_id(int mekan_id) {
        this.mekan_id = mekan_id;
    }

    public String getYorumlar() {
        return yorumlar;
    }

    public void setYorumlar(String yorumlar) {
        this.yorumlar = yorumlar;
    }

    public Date getTarih_saat() {
        return tarih_saat;
    }

    public void setTarih_saat(Date tarih_saat) {
        this.tarih_saat = tarih_saat;
    }
    
    
    
}
