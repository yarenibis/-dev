/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

/**
 *
 * @author yaren
 */
class Odeme {
    
    private int odeme_id;
    private int miktar;
    private Date tarih;
    private Kullanıcı kullanıcı_id;

    public Odeme() {
    }

    public Odeme(int odeme_id, int miktar, Date tarih, Kullanıcı kullanıcı_id) {
        this.odeme_id = odeme_id;
        this.miktar = miktar;
        this.tarih = tarih;
        this.kullanıcı_id = kullanıcı_id;
    }

    public int getOdeme_id() {
        return odeme_id;
    }

    public void setOdeme_id(int odeme_id) {
        this.odeme_id = odeme_id;
    }

    public int getMiktar() {
        return miktar;
    }

    public void setMiktar(int miktar) {
        this.miktar = miktar;
    }

    public Date getTarih() {
        return tarih;
    }

    public void setTarih(Date tarih) {
        this.tarih = tarih;
    }

    public Kullanıcı getKullanıcı_id() {
        return kullanıcı_id;
    }

    public void setKullanıcı_id(Kullanıcı kullanıcı_id) {
        this.kullanıcı_id = kullanıcı_id;
    }
    
    
    
    
}
