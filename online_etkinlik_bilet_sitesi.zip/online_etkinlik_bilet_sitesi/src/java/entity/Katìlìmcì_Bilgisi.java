/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;

/**
 *
 * @author yaren
 */
public class Katılımcı_Bilgisi {
    private int  katılımcı_bilgisi_id;
    private Kullanıcı kullanıcı_id;
    private Etkinlik etkinlik_id;
    private Date tarih;

    public Katılımcı_Bilgisi() {
    }

    public Katılımcı_Bilgisi(int katılımcı_bilgisi_id, Kullanıcı kullanıcı_id, Etkinlik etkinlik_id, Date tarih) {
        this.katılımcı_bilgisi_id = katılımcı_bilgisi_id;
        this.kullanıcı_id = kullanıcı_id;
        this.etkinlik_id = etkinlik_id;
        this.tarih = tarih;
    }

    public int getKatılımcı_bilgisi_id() {
        return katılımcı_bilgisi_id;
    }

    public void setKatılımcı_bilgisi_id(int katılımcı_bilgisi_id) {
        this.katılımcı_bilgisi_id = katılımcı_bilgisi_id;
    }

    public Kullanıcı getKullanıcı_id() {
        return kullanıcı_id;
    }

    public void setKullanıcı_id(Kullanıcı kullanıcı_id) {
        this.kullanıcı_id = kullanıcı_id;
    }

    public Etkinlik getEtkinlik_id() {
        return etkinlik_id;
    }

    public void setEtkinlik_id(Etkinlik etkinlik_id) {
        this.etkinlik_id = etkinlik_id;
    }

    public Date getTarih() {
        return tarih;
    }

    public void setTarih(Date tarih) {
        this.tarih = tarih;
    }
    
    
    
    
    
}
