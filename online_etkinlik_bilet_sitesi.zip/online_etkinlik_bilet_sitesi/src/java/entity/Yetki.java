/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author yaren
 */
class Yetki {
    private int yetki_id;
    private String yetki_adi;
    private String şifre;

    public Yetki() {
    }

    public Yetki(int yetki_id, String yetki_adi, String şifre) {
        this.yetki_id = yetki_id;
        this.yetki_adi = yetki_adi;
        this.şifre = şifre;
    }

    public int getYetki_id() {
        return yetki_id;
    }

    public void setYetki_id(int yetki_id) {
        this.yetki_id = yetki_id;
    }

    public String getYetki_adi() {
        return yetki_adi;
    }

    public void setYetki_adi(String yetki_adi) {
        this.yetki_adi = yetki_adi;
    }

    public String getŞifre() {
        return şifre;
    }

    public void setŞifre(String şifre) {
        this.şifre = şifre;
    }
    
    
}
