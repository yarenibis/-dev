/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author yaren
 */
class Indirim {
    
    private int indirim_id;
    private String adı;
    private int miktar;

    public Indirim() {
    }

    public Indirim(int indirim_id, String adı, int miktar) {
        this.indirim_id = indirim_id;
        this.adı = adı;
        this.miktar = miktar;
    }

    public int getIndirim_id() {
        return indirim_id;
    }

    public void setIndirim_id(int indirim_id) {
        this.indirim_id = indirim_id;
    }

    public String getAdı() {
        return adı;
    }

    public void setAdı(String adı) {
        this.adı = adı;
    }

    public int getMiktar() {
        return miktar;
    }

    public void setMiktar(int miktar) {
        this.miktar = miktar;
    }
    
    
}
