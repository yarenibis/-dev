/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author yaren
 */
public class Kullanıcı {
    private int kullanıcı_id;
    private String adı;
    private String soyadı;
    private String mail;
    private String şifre;
    private Yetki yetki_id;

    public Kullanıcı() {
    }

    public Kullanıcı(String mail, String şifre) {
        this.mail = mail;
        this.şifre = şifre;
    }

    
    public Kullanıcı(int kullanıcı_id, String adı, String soyadı, String mail, String şifre) {
        this.kullanıcı_id = kullanıcı_id;
        this.adı = adı;
        this.soyadı = soyadı;
        this.mail = mail;
        this.şifre = şifre;
    }

    public Kullanıcı(int kullanıcı_id, String adı, String soyadı, String mail, String şifre, Yetki yetki_id) {
        this.kullanıcı_id = kullanıcı_id;
        this.adı = adı;
        this.soyadı = soyadı;
        this.mail = mail;
        this.şifre = şifre;
        this.yetki_id = yetki_id;
    }

    public int getKullanıcı_id() {
        return kullanıcı_id;
    }

    public void setKullanıcı_id(int kullanıcı_id) {
        this.kullanıcı_id = kullanıcı_id;
    }

    public String getAdı() {
        return adı;
    }

    public void setAdı(String adı) {
        this.adı = adı;
    }

    public String getSoyadı() {
        return soyadı;
    }

    public void setSoyadı(String soyadı) {
        this.soyadı = soyadı;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getŞifre() {
        return şifre;
    }

    public void setŞifre(String şifre) {
        this.şifre = şifre;
    }

    public Yetki getYetki_id() {
        return yetki_id;
    }

    public void setYetki_id(Yetki yetki_id) {
        this.yetki_id = yetki_id;
    }
    
    
    
}
