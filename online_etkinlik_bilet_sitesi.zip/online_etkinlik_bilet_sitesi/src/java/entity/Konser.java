/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.Date;


public class Konser {
    private int konser_id;
    private String konser_adi;
    private String sanatci_adi_soyadi;
    private Date tarih;

    public Konser() {
    }

    public Konser(int konser_id, String konser_adi, String sanatci_adi_soyadi, Date tarih) {
        this.konser_id = konser_id;
        this.konser_adi = konser_adi;
        this.sanatci_adi_soyadi = sanatci_adi_soyadi;
        this.tarih = tarih;
    }

    public int getKonser_id() {
        return konser_id;
    }

    public void setKonser_id(int konser_id) {
        this.konser_id = konser_id;
    }

    public String getKonser_adi() {
        return konser_adi;
    }

    public void setKonser_adi(String konser_adi) {
        this.konser_adi = konser_adi;
    }

    public String getSanatci_adi_soyadi() {
        return sanatci_adi_soyadi;
    }

    public void setSanatci_adi_soyadi(String sanatci_adi_soyadi) {
        this.sanatci_adi_soyadi = sanatci_adi_soyadi;
    }

    public Date getTarih() {
        return tarih;
    }

    public void setTarih(Date tarih) {
        this.tarih = tarih;
    }
    
    
    
}
