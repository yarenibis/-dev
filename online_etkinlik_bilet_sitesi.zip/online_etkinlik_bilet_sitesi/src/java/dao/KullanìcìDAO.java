/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.Kullanıcı;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.DBConnection;


public class KullanıcıDAO extends DBConnection {
    
    private Connection db;

    public List<Kullanıcı> getKullanıcıList() {
        List<Kullanıcı> kullanıcıList = new ArrayList();
        try {
            Statement st = this.getDb().createStatement();
            String query = "select mail,şifre from kullanıcı";
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                kullanıcıList.add(new Kullanıcı(
                        rs.getString("mail"),
                        rs.getString("şifre")
                ));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return kullanıcıList;
    }
    
    
    
   
    
    
    public void kullanıcı_çıkışı(){
        
    }
    public void kullanıcı_güncelle(){
        
    }

    public Connection getDb() {
    if(this.db==null){
     this.db=this.connect();
}
    return db;
    }
    
    
    
}
